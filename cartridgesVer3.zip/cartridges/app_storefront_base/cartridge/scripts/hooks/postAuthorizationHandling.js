'use strict';

// Dummy implementation

/**
 * This function is to handle the post payment authorization customizations
 * @param {Object} result - Authorization Result
 */
function postAuthorization(result) { // eslint-disable-line no-unused-vars
    return;
}

exports.postAuthorization = postAuthorization;
